<html>
    <body>
        <h1>Hello,}</h1>

        <form action="http://localhost:8084/api/v1/all-users" method="GET">
        
        <button>Get all users - JSON</button>
        <!-- If you want to be more explicit... -->

        </form>

    </body>
</html>